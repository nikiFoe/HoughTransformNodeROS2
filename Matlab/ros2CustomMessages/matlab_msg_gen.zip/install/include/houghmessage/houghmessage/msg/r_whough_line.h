// generated from rosidl_generator_c/resource/idl.h.em
// with input from houghmessage:msg/RWhoughLine.idl
// generated code does not contain a copyright notice

#ifndef HOUGHMESSAGE__MSG__R_WHOUGH_LINE_H_
#define HOUGHMESSAGE__MSG__R_WHOUGH_LINE_H_

#include "houghmessage/msg/detail/r_whough_line__struct.h"
#include "houghmessage/msg/detail/r_whough_line__functions.h"
#include "houghmessage/msg/detail/r_whough_line__type_support.h"

#endif  // HOUGHMESSAGE__MSG__R_WHOUGH_LINE_H_
