// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef HOUGHMESSAGE__MSG__R_WHOUGH_LINE_HPP_
#define HOUGHMESSAGE__MSG__R_WHOUGH_LINE_HPP_

#include "houghmessage/msg/detail/r_whough_line__struct.hpp"
#include "houghmessage/msg/detail/r_whough_line__builder.hpp"
#include "houghmessage/msg/detail/r_whough_line__traits.hpp"

#endif  // HOUGHMESSAGE__MSG__R_WHOUGH_LINE_HPP_
